package com.capgemini.capstore.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.capstore.beans.Customer;

import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Product;

public interface ServiceRepo {

	public List<Customer> getAllCustomers();
	public List<Merchant> getAllMerchants();
	public List<Product> getAllProducts();
}
