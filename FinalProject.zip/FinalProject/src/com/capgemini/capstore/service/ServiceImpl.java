package com.capgemini.capstore.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.repo.CustomerRepo;
import com.capgemini.capstore.repo.MerchantRepo;
import com.capgemini.capstore.repo.ProductRepo;

@Component(value="serviceRepo")
public class ServiceImpl implements ServiceRepo {


	@Autowired
	private CustomerRepo customerRepo;
	@Autowired
	private MerchantRepo merchantRepo ;
	@Autowired
	private ProductRepo productRepo;

	@Override
	public  List<Customer> getAllCustomers() {

		return customerRepo.getAllCustomers();	
	}

	@Override
	public List<Merchant> getAllMerchants() {

		return merchantRepo.getAllMerchants();
	}

	@Override
	public List<Product> getAllProducts() {

		return productRepo.getAllProducts();
	}

}
