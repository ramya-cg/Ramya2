package com.capgemini.capstore.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.service.ServiceRepo;


@Controller
public class CapstoreActionController {

	public static int id;
	public static int merchantId;
	public static int productId;
	
	@Autowired
	ServiceRepo serviceRepo;
	
	@RequestMapping(value="/customerList")
	public ModelAndView getAllCustomers() {
	List<Customer> customer =serviceRepo.getAllCustomers();
	return  new ModelAndView("customerPage","customer",customer);
	}
	
	@RequestMapping(value="/merchantList")
	public ModelAndView getAllMerchants() {
	List<Merchant> merchant =serviceRepo.getAllMerchants();
	return  new ModelAndView("merchantPage","merchant",merchant);
	}
	
	@RequestMapping(value="/productList")
	public ModelAndView getAllProducts() {
	List<Product> product =serviceRepo.getAllProducts();
	return  new ModelAndView("productPage","product",product);
	}
}
