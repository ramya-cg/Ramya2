package com.capgemini.capstore.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Product;



@Controller
public class URIController {
	
	@RequestMapping(value="/")
	public String getAdminHome() {
		return "AdminHome";}
	
	@ModelAttribute("Customer")
	public Customer getCustomer(){
		return new Customer();}
	
	@ModelAttribute("Merchant")
	public Merchant getMerchant(){
		return new Merchant();}
	
	@ModelAttribute("Product")
	public Product getProduct(){
		return new Product();}


}
